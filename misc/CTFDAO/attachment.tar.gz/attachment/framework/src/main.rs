use solana_sdk::transaction::Transaction;
use std::env;
use std::io::Write;

use sol_ctf_framework::ChallengeBuilder;

use anchor_lang::{InstructionData, ToAccountMetas, Discriminator, AnchorDeserialize};

use solana_sdk::compute_budget::ComputeBudgetInstruction;

use solana_program::instruction::Instruction;
use solana_program::system_instruction;
use solana_program::sysvar;
use solana_program_test::tokio;
use solana_sdk::pubkey::Pubkey;
use solana_sdk::signature::Signer;
use solana_sdk::signer::keypair::Keypair;
use std::error::Error;
use base64::{engine::general_purpose, Engine as _};

use std::net::{TcpListener, TcpStream};

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:1337")?;

    println!("starting server at port 1337!");

    for stream in listener.incoming() {
        let stream = stream.unwrap();

        tokio::spawn(async {
            if let Err(err) = handle_connection(stream).await {
                println!("error: {:?}", err);
            }
        });
    }
    Ok(())
}

async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    let chall_id = builder.add_program("./chall/target/deploy/chall.so", Some(chall::id()));
    let solve_id = builder.input_program()?;

    let mut chall = builder.build().await;

    // -------------------------------------------------------------------------
    // [setup env] initialize
    // -------------------------------------------------------------------------
    let program_id = chall_id;

    println!("Program ID: {}\n", program_id);

    let admin_keypair = chall.ctx.payer.insecure_clone();
    let admin = admin_keypair.pubkey();

    // Create DAO
    let (dao, _dao_bump) = Pubkey::find_program_address(&["DAO".as_bytes(), admin.as_ref()], &program_id);
    let (vault, _vault_bump) = Pubkey::find_program_address(&["VAULT".as_bytes(), dao.as_ref()], &program_id);
    
    let ix = chall::instruction::CreateDao { quorum_votes: 100_000_000 };
    let ix_accounts = chall::accounts::CreateDao {
        dao,
        vault,
        payer: admin,
        system_program: solana_program::system_program::id(),
    };

    chall
        .run_ixs_full(
            &[Instruction::new_with_bytes(
                program_id,
                &ix.data(),
                ix_accounts.to_account_metas(None),
            )],
            &[&admin_keypair],
            &admin,
        ).await?;

    // -------------------------------------------------------------------------

    // Create Proposal
    let (proposal, _proposal_bump) = Pubkey::find_program_address(&["PROPOSAL".as_bytes(), dao.as_ref(), admin.as_ref()], &program_id);

    let ix = chall::instruction::CreateProposal {
        description: "Give user the flag".to_string(),
    };
    let ix_accounts = chall::accounts::CreateProposal {
        proposal,
        dao,
        proposer: admin,
        payer: admin,
        clock: sysvar::clock::id(),
        system_program: solana_program::system_program::id(),
    };

    chall
        .run_ixs_full(
            &[Instruction::new_with_bytes(
                program_id,
                &ix.data(),
                ix_accounts.to_account_metas(None),
            )],
            &[&admin_keypair],
            &admin,
        ).await?;

    // -------------------------------------------------------------------------

    // Vote on proposal
    let (votestate, _votestate_bump) = Pubkey::find_program_address(&["VOTE".as_bytes(), proposal.as_ref(), admin.as_ref()], &program_id);

    let ix = chall::instruction::Vote {
        amount: 50_000_001,
        support: false,
    };
    let ix_accounts = chall::accounts::Vote {
        votestate,
        proposal,
        voter: admin,
        clock: sysvar::clock::id(),
        system_program: solana_program::system_program::id(),
    };

    chall
        .run_ixs_full(
            &[Instruction::new_with_bytes(
                program_id,
                &ix.data(),
                ix_accounts.to_account_metas(None),
            )],
            &[&admin_keypair],
            &admin,
        ).await?;
    
    // -------------------------------------------------------------------------

    let user_keypair = Keypair::new();
    let user = user_keypair.pubkey();
    // You only have 0.05 SOL :(
    chall
        .run_ix(system_instruction::transfer(&admin, &user, 50_000_000))
        .await?;

    // provided info
    writeln!(socket, "admin: {}", admin)?;
    writeln!(socket, "user: {}", user)?;
    writeln!(socket, "dao: {}", dao)?;
    writeln!(socket, "vault: {}", vault)?;
    writeln!(socket, "proposal: {}", proposal)?;
    
    let solve_ix = chall.read_instruction(solve_id)?;
    
    let bump_budget = ComputeBudgetInstruction::set_compute_unit_limit(10_000_000);
    
    let mut tx = Transaction::new_with_payer(
        &[bump_budget, solve_ix],
        Some(&user),
    );

    tx.sign(&[&user_keypair], chall.ctx.last_blockhash);

    let logs = chall.ctx.banks_client.process_transaction_with_metadata(tx).await?.metadata.unwrap().log_messages;

    // Parse events triggered by the exploit
    for log in logs {
        if let Some(data) = log.strip_prefix("Program data: ") {
            let bytes = general_purpose::STANDARD.decode(data.as_bytes())?;
            let (discriminantor, event) = bytes.split_at(8);
            let discriminantor: [u8; 8] = discriminantor.try_into()?;
            match discriminantor {
                chall::DaoCreated::DISCRIMINATOR => {
                    let event = chall::DaoCreated::try_from_slice(event)?;
                    println!("DaoCreated: {:?}", event);
                    writeln!(socket, "Wait, you are not allow to do this!")?;
                    return Ok(());
                },
                chall::ProposalCreated::DISCRIMINATOR => {
                    let event = chall::ProposalCreated::try_from_slice(event)?;
                    println!("ProposalCreated: {:?}", event);
                },
                chall::VoteCast::DISCRIMINATOR => {
                    let event = chall::VoteCast::try_from_slice(event)?;
                    println!("VoteCast: {:?}", event);
                },
                chall::ProposalFinalized::DISCRIMINATOR => {
                    let event = chall::ProposalFinalized::try_from_slice(event)?;
                    if event.did_pass && event.dao == dao && event.id == 0 { // 0 is the proposal id of "Give user the flag"
                        writeln!(socket, "Congrats!")?;
                        if let Ok(flag) = env::var("FLAG") {
                            writeln!(socket, "flag: {:?}", flag)?;
                        } else {
                            writeln!(socket, "flag not found, please contact admin")?;
                        }
                    } else {
                        writeln!(socket, "...?")?;
                    }
                },
                _ => {}
            }
        }
    }
    
    Ok(())
}