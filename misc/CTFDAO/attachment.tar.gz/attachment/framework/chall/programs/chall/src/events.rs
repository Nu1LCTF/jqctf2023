use anchor_lang::prelude::*;

/// Event emitted when a DAO is created
#[event]
#[derive(Debug)]
pub struct DaoCreated {
    /// The public key of the DAO that was created
    #[index]
    pub dao: Pubkey,
    /// The public key of the vault
    pub vault: Pubkey,
    /// The public key of the creator
    pub creator: Pubkey,
}

/// Event emitted when a proposal is created
#[event]
#[derive(Debug)]
pub struct ProposalCreated {
    /// The public key of the DAO that owns this proposal
    #[index]
    pub dao: Pubkey,
    /// The unique identifier of this proposal
    #[index]
    pub id: u64,
    /// The public key of the proposal's creator
    pub proposer: Pubkey,
    /// The number of votes in support required for this proposal to succeed
    pub quorum_votes: u64,
    /// The timestamp when voting begins for this proposal
    pub start_time: u64,
    /// The timestamp when voting ends for this proposal
    pub end_time: u64,
    /// The description of this proposal
    pub description: String,
}

/// Event emitted when a vote is cast
#[event]
#[derive(Debug)]
pub struct VoteCast {
    /// The public key of the proposal that this vote is for
    #[index]
    pub proposal: Pubkey,
    /// The public key of the voter
    #[index]
    pub voter: Pubkey,
    /// The number of tokens that the voter has voted with
    pub amount: u64,
    /// Whether the voter supports the proposal
    pub support: bool,
}

/// Event emitted when a proposal is finalized
#[event]
#[derive(Debug)]
pub struct ProposalFinalized {
    /// The public key of the DAO that owns this proposal
    #[index]
    pub dao: Pubkey,
    /// The unique identifier of this proposal
    #[index]
    pub id: u64,
    /// The public key of the proposal's creator
    pub proposer: Pubkey,
    /// The number of votes in support required for this proposal to succeed
    pub quorum_votes: u64,
    /// The number of votes in support of this proposal
    pub for_votes: u64,
    /// The number of votes in opposition to this proposal
    pub against_votes: u64,
    /// Whether the proposal succeeded
    pub did_pass: bool,
}