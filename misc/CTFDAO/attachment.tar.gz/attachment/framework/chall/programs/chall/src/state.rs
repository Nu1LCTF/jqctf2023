use anchor_lang::prelude::*;

#[account]
#[derive(Debug, Default)]
pub struct Dao {
    /// The total number of [Proposal]s
    pub proposal_count: u64,
    /// The number of votes in support of a proposal required in order for a quorum to be reached and for a vote to succeed
    pub quorum_votes: u64,
    /// The duration of voting on a proposal, in seconds
    pub voting_period: u64,
    /// The vault that holds the DAO's funds
    pub vault: Pubkey,
}

#[account]
#[derive(Debug, Default)]
pub struct Proposal {
    /// The public key of the DAO that owns this proposal
    pub dao: Pubkey,
    /// The unique identifier of this proposal
    pub id: u64,
    /// The public key of the proposal's creator
    pub proposer: Pubkey,
    /// The number of votes in support required for this proposal to succeed
    pub quorum_votes: u64,
    /// The number of votes in support of this proposal
    pub for_votes: u64,
    /// The number of votes in opposition to this proposal
    pub against_votes: u64,
    /// The timestamp when voting begins for this proposal
    pub start_time: u64,
    /// The timestamp when voting ends for this proposal
    pub end_time: u64,
    /// The description of this proposal
    pub description: String,
}

#[account]
#[derive(Debug, Default)]
pub struct VoteState {
    /// The public key of the proposal that this vote is for
    pub proposal: Pubkey,
    /// The public key of the voter
    pub voter: Pubkey,
    /// The number of tokens that the voter has voted with
    pub amount: u64,
    /// Whether the voter supports the proposal
    pub support: bool,
}