use anchor_lang::prelude::*;

mod events;
mod state;

pub use events::*;
pub use state::*;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod chall {
    use super::*;

    /// Creates a new DAO
    pub fn create_dao(ctx: Context<CreateDao>, quorum_votes: u64) -> Result<()> {
        let dao = &mut ctx.accounts.dao;

        dao.proposal_count = 0;
        dao.quorum_votes = quorum_votes;
        dao.voting_period = 60 * 60 * 24 * 7; // 7 days
        dao.vault = *ctx.accounts.vault.to_account_info().key;

        emit!(DaoCreated {
            dao: *ctx.accounts.dao.to_account_info().key,
            creator: *ctx.accounts.payer.to_account_info().key,
            vault: *ctx.accounts.vault.to_account_info().key,
        });
        Ok(())
    }

    /// Creates a new proposal
    pub fn create_proposal(ctx: Context<CreateProposal>, description: String) -> Result<()> {
        let proposal = &mut ctx.accounts.proposal;

        proposal.dao = *ctx.accounts.dao.to_account_info().key;
        proposal.id = ctx.accounts.dao.proposal_count;
        proposal.proposer = *ctx.accounts.proposer.to_account_info().key;
        proposal.quorum_votes = ctx.accounts.dao.quorum_votes;
        proposal.for_votes = 0;
        proposal.against_votes = 0;
        proposal.start_time = ctx.accounts.clock.unix_timestamp as u64;
        proposal.end_time = ctx.accounts.clock.unix_timestamp as u64 + ctx.accounts.dao.voting_period;
        proposal.description = description;
        ctx.accounts.dao.proposal_count += 1;

        emit!(ProposalCreated {
            dao: *ctx.accounts.dao.to_account_info().key,
            id: proposal.id,
            proposer: *ctx.accounts.proposer.to_account_info().key,
            quorum_votes: proposal.quorum_votes,
            start_time: proposal.start_time,
            end_time: proposal.end_time,
            description: proposal.description.clone(),
        });
        Ok(())
    }

    /// Casts a vote on a proposal (I'm too lazy to implement staking-related stuff, so I'll just check user's balance for simplicity)
    pub fn vote(ctx: Context<Vote>, amount: u64, support: bool) -> Result<()> {
        let proposal = &mut ctx.accounts.proposal;
        let voter = &mut ctx.accounts.voter;

        if (ctx.accounts.clock.unix_timestamp as u64) < proposal.start_time {
            return Err(ErrorCode::VotingPeriodNotStarted.into());
        }

        if (ctx.accounts.clock.unix_timestamp as u64) > proposal.end_time {
            return Err(ErrorCode::VotingPeriodEnded.into());
        }

        if amount > voter.lamports() {
            return Err(ErrorCode::InvalidVoteAmount.into());
        }

        let vote_state = &mut ctx.accounts.votestate;
        
        vote_state.proposal = *proposal.to_account_info().key;
        vote_state.voter = *voter.to_account_info().key;
        vote_state.amount = amount;
        vote_state.support = support;

        if support {
            proposal.for_votes += amount;
        } else {
            proposal.against_votes += amount;
        }

        emit!(VoteCast {
            proposal: *proposal.to_account_info().key,
            voter: *voter.to_account_info().key,
            amount: amount,
            support: support,
        });

        Ok(())
    }

    /// Finalizes a proposal
    pub fn close_proposal(ctx: Context<CloseProposal>) -> Result<()> {
        let proposal = &mut ctx.accounts.proposal;

        if (ctx.accounts.clock.unix_timestamp as u64) < proposal.end_time && std::cmp::max(proposal.for_votes, proposal.against_votes) < proposal.quorum_votes {
            return Err(ErrorCode::VotingStillInProgress.into());
        }
        
        emit!(ProposalFinalized {
            dao: *ctx.accounts.dao.to_account_info().key,
            id: proposal.id,
            proposer: proposal.proposer,
            quorum_votes: proposal.quorum_votes,
            for_votes: proposal.for_votes,
            against_votes: proposal.against_votes,
            did_pass: proposal.for_votes > proposal.against_votes,
        });

        Ok(())
    }

}

#[derive(Accounts)]
pub struct CreateDao<'info> {
    #[account(
        init,
        seeds = ["DAO".as_bytes(), payer.key().as_ref()],
        bump,
        payer = payer,
        space = 8 + std::mem::size_of::<Dao>(),
    )]
    pub dao: Account<'info, Dao>,
    
    #[account(
        init,
        seeds = ["VAULT".as_bytes(), dao.key().as_ref()],
        bump,
        payer = payer,
        space = 0,
    )]
    pub vault: AccountInfo<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateProposal<'info> {
    #[account(
        init,
        seeds = ["PROPOSAL".as_bytes(), dao.key().as_ref(), payer.key().as_ref()],
        bump,
        payer = payer,
        space = 8 + std::mem::size_of::<Proposal>(),
    )]
    pub proposal: Account<'info, Proposal>,
    
    #[account(mut)]
    pub dao: Account<'info, Dao>,
    
    #[account(mut)]
    pub proposer: Signer<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>,

    pub clock: Sysvar<'info, Clock>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Vote<'info> {
    #[account(
        init,
        seeds = ["VOTE".as_bytes(), proposal.key().as_ref(), voter.key().as_ref()],
        bump,
        payer = voter,
        space = 8 + std::mem::size_of::<VoteState>(),
    )]
    pub votestate: Account<'info, VoteState>,

    #[account(mut)]
    pub proposal: Account<'info, Proposal>,

    #[account(mut)]
    pub voter: Signer<'info>,

    pub clock: Sysvar<'info, Clock>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CloseProposal<'info> {
    #[account(
        mut,
        close = vault,
        has_one = dao,
    )]
    pub proposal: Account<'info, Proposal>,

    #[account(
        has_one = vault,
    )]
    pub dao: Account<'info, Dao>,

    #[account(
        mut,
        seeds = ["VAULT".as_bytes(), dao.key().as_ref()],
        bump,
    )]
    pub vault: AccountInfo<'info>,

    pub clock: Sysvar<'info, Clock>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Voting period has not started")]
    VotingPeriodNotStarted,
    #[msg("Voting period has ended")]
    VotingPeriodEnded,
    #[msg("Voting still in progress")]
    VotingStillInProgress,
    #[msg("Invalid vote amount")]
    InvalidVoteAmount,
}