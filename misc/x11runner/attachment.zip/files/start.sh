#!/bin/sh

if [ -z "$FLAG" ]; then
  echo "FLAG is not set"
else
  echo $FLAG > /flag
fi

FLAG=no
export FLAG=no
unset FLAG

export DISPLAY=:1
runuser -u ctf -- Xvfb -listen tcp -ac :1 -screen 0 1024x768x8 &
runuser -u ctf -- openbox &
while true; do python3 /server.py; sleep 5s; done
