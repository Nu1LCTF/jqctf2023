import base64
import gzip
import os
import signal
import resource
import socket

listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
listen_address = ('', 10000)
listen_socket.bind(listen_address)
listen_socket.listen(1)
client_socket, client_address = listen_socket.accept()

listen_socket.close()

os.dup2(client_socket.fileno(), 0)  # Redirect stdin
os.dup2(client_socket.fileno(), 1)  # Redirect stdout
os.dup2(client_socket.fileno(), 2)  # Redirect stderr
client_socket.close()


signal.alarm(10)
resource.setrlimit(resource.RLIMIT_CPU,(2,2))

ctf_uid=os.stat("/home/ctf").st_uid
os.chroot("/home/ctf")
os.chdir("/")
os.setresgid(ctf_uid,ctf_uid,ctf_uid)
os.setresuid(ctf_uid,ctf_uid,ctf_uid)

# Ask user to input a base64 string
base64_string = input("Enter your program: ")

if len(base64_string) > 8192:
    raise "too long"
# Decode the string and decompress using gzip
decoded_data = base64.b85decode(base64_string)
decompressed_data = gzip.decompress(decoded_data)

if len(decoded_data) > 1024*1024:
    raise "too big"

# Write the content to the file /home/ctf/prog
file_path = "/prog"
if os.path.exists(file_path):
    os.unlink(file_path)

with open(file_path, "wb") as file:
    file.write(decompressed_data)

os.chmod(file_path,0o700)
# Change root directory to /home/ctf and execute ./prog
os.execle("/prog","/prog",{})
